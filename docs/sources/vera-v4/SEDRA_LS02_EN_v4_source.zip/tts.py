import soundfile as sf
from kokoro_onnx import Kokoro
k=Kokoro('/tmp/kok/kokoro-v1.0.onnx','/tmp/kok/voices-v1.0.bin')
lines=["A big feeling can make it hard to choose what to do.","Stop.","Pause and notice how you feel.","Think.","What could you say or do that is kind and safe?","Do.","Try your choice.","You can stop and think again."]
for i,t in enumerate(lines):
    s,sr=k.create(t,voice='af_heart',speed=1.0,lang='en-us')
    sf.write(f'aud/l{i}.wav',s,sr); print(i,sr,round(len(s)/sr,2),t)
