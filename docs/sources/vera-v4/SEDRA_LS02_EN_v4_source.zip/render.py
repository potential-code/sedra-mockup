import math, subprocess, json, sys
import numpy as np, soundfile as sf
from PIL import Image, ImageDraw, ImageFont

W, H, FPS = 1920, 1080, 30
D = '/tmp/claude-0/v4/'
F = '/usr/share/fonts/opentype/inter/'
def font(w, s): return ImageFont.truetype(F + f'Inter-{w}.otf', s)
BG = (245, 246, 238); DARK = (75, 102, 47); MID = (109, 146, 61); LIME = (152, 172, 60)
PALE = (190, 204, 150); BROWN = (134, 117, 76); CARD = (236, 241, 226); WHITE = (255, 255, 255)

# ---------- audio timeline ----------
sr = 24000
L = [sf.read(D + f'aud/l{i}.wav')[0] for i in range(8)]
LEAD, GAP, INNER, HOLD = 0.4, 1.2, 0.35, 2.0
groups = [[0], [1, 2], [3, 4], [5, 6, 7]]
t = LEAD; seg = {}; scene_start = []; scene_speech_end = []
for gi, g in enumerate(groups):
    scene_start.append(t if gi == 0 else t)
    for j, i in enumerate(g):
        if j: t += INNER
        seg[i] = (t, t + len(L[i]) / sr); t = seg[i][1]
    scene_speech_end.append(t)
    if gi < 3: t += GAP
TOTAL = t + HOLD
N = int(math.ceil(TOTAL * FPS)); TOTAL = N / FPS
audio = np.zeros(int(TOTAL * sr) + 1)
for i, (a, b) in seg.items():
    s = int(a * sr); audio[s:s + len(L[i])] += L[i]
sf.write(D + 'narration_v4.wav', audio, sr)

# scene windows: scene k visible from (start of its gap transition) to next transition
# transitions happen in the gap: old content fades out over first 0.4 s, new label slides in 0.2..0.8 s
def ease(x): x = max(0, min(1, x)); return 1 - (1 - x) ** 3

logo = Image.open(D + 'logo_src.png').crop((1340, 620, 2500, 1500))
logo.thumbnail((250, 190), Image.LANCZOS)

def rr(d, box, r, fill=None, outline=None, width=0):
    d.rounded_rectangle(box, r, fill=fill, outline=outline, width=width)

def ctext(d, cx, cy, s, f, fill):
    b = d.textbbox((0, 0), s, font=f); d.text((cx - (b[2] - b[0]) / 2 - b[0], cy - (b[3] - b[1]) / 2 - b[1]), s, font=f, fill=fill)

def layer_alpha(img, a):
    if a >= 1: return img
    arr = np.array(img); arr[..., 3] = (arr[..., 3] * max(0, a)).astype(np.uint8); return Image.fromarray(arr)

def card(d, cx, cy, w, h, text, fsize=64, a=1.0, border=DARK, fill=CARD, tcol=DARK, icon=None):
    x0, y0 = cx - w / 2, cy - h / 2
    rr(d, (x0 + 6, y0 + 10, x0 + w + 6, y0 + h + 10), 34, fill=(225, 228, 215))
    rr(d, (x0, y0, x0 + w, y0 + h), 34, fill=fill, outline=border, width=8)
    tx = cx
    if icon:
        icon(d, x0 + 90, cy); tx = cx + 45
    ctext(d, tx, cy, text, font('Bold', fsize), tcol)

def heart(d, cx, cy, s, col):
    pts = []
    for k in range(120):
        th = 2 * math.pi * k / 120
        x = 16 * math.sin(th) ** 3
        y = -(13 * math.cos(th) - 5 * math.cos(2 * th) - 2 * math.cos(3 * th) - math.cos(4 * th))
        pts.append((cx + x * s, cy + y * s))
    d.polygon(pts, fill=col)

def octagon(d, cx, cy, r, col):
    pts = [(cx + r * math.cos(math.pi / 8 + k * math.pi / 4), cy + r * math.sin(math.pi / 8 + k * math.pi / 4)) for k in range(8)]
    d.polygon(pts, fill=col)

def arrow(d, x0, y0, ang, ln, col, w=16):
    x1, y1 = x0 + ln * math.cos(ang), y0 + ln * math.sin(ang)
    d.line((x0, y0, x1, y1), fill=col, width=w)
    for s in (1, -1):
        a2 = ang + math.pi + s * 0.5
        d.line((x1, y1, x1 + 40 * math.cos(a2), y1 + 40 * math.sin(a2)), fill=col, width=w)

def pause_icon(d, x, y):
    d.rounded_rectangle((x - 30, y - 34, x - 10, y + 34), 6, fill=MID); d.rounded_rectangle((x + 10, y - 34, x + 30, y + 34), 6, fill=MID)
def heart_icon(d, x, y): heart(d, x, y + 4, 2.6, MID)
def chat_icon(d, x, y):
    d.rounded_rectangle((x - 50, y - 36, x + 50, y + 26), 14, fill=MID); d.polygon([(x - 30, y + 24), (x - 42, y + 50), (x - 8, y + 24)], fill=MID)
    for k in (-24, 0, 24): d.ellipse((x + k - 7, y - 12, x + k + 7, y + 2), fill=WHITE)
def break_icon(d, x, y):
    d.ellipse((x - 38, y - 38, x + 38, y + 38), outline=MID, width=9); d.line((x, y, x, y - 24), fill=MID, width=8); d.line((x, y, x + 18, y + 10), fill=MID, width=8)

def appear(tnow, t0, dur=0.45):
    return ease((tnow - t0) / dur)

# ---------- scene content (relative to frame time) ----------
CY = 470  # centre of main content area
def scene_content(k, tn):
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    if k == 0:
        a, b = seg[0]
        p = appear(tn, a + 0.1)
        if p > 0:
            heart(d, W / 2 - 330 + 0 * (1 - p), CY + 20 + 40 * (1 - p), 13 * (0.7 + 0.3 * p), (152, 172, 60, int(255 * p)))
        p2 = appear(tn, a + 1.3)
        if p2 > 0:
            sub = Image.new('RGBA', (W, H), (0, 0, 0, 0)); sd = ImageDraw.Draw(sub)
            ox, oy = W / 2 + 230, CY + 30
            for ang in (-2.4, -0.75, 0.6):
                arrow(sd, ox, oy, ang, 170, DARK)
            sd.ellipse((ox - 26, oy - 26, ox + 26, oy + 26), fill=DARK)
            ctext(sd, ox + 330, CY + 10, '?', font('Bold', 220), MID)
            sub = layer_alpha(sub.transform((W, H), Image.AFFINE, (1, 0, -50 * (1 - p2), 0, 1, 0)), p2)
            im = Image.alpha_composite(im, sub)
    elif k == 1:
        a = seg[1][0]; a2 = seg[2][0]
        p = appear(tn, a)
        if p > 0:
            r = 150 * (0.8 + 0.2 * p)
            sub = Image.new('RGBA', (W, H), (0, 0, 0, 0)); sd = ImageDraw.Draw(sub)
            octagon(sd, W / 2 - 520, CY + 10, r, (176, 58, 46)); octagon(sd, W / 2 - 520, CY + 10, r - 14, (196, 72, 58))
            ctext(sd, W / 2 - 520, CY + 10, 'STOP', font('Bold', int(70 * (0.8 + 0.2 * p))), WHITE)
            im = Image.alpha_composite(im, layer_alpha(sub, p))
        for j, (txt, ic, t0, w) in enumerate([('Pause', pause_icon, a2, 470), ('Notice how you feel', heart_icon, a2 + 0.75, 880)]):
            p = appear(tn, t0)
            if p > 0:
                sub = Image.new('RGBA', (W, H), (0, 0, 0, 0)); sd = ImageDraw.Draw(sub)
                card(sd, W / 2 + 260, CY - 100 + j * 210, w, 160, txt, 60, icon=ic)
                sub = sub.transform((W, H), Image.AFFINE, (1, 0, -80 * (1 - p), 0, 1, 0))
                im = Image.alpha_composite(im, layer_alpha(sub, p))
    elif k == 2:
        a = seg[3][0]; a2 = seg[4][0]
        p = appear(tn, a)
        if p > 0:
            sub = Image.new('RGBA', (W, H), (0, 0, 0, 0)); sd = ImageDraw.Draw(sub)
            bx, by = W / 2 - 560, CY - 40
            sd.ellipse((bx - 150, by - 100, bx + 150, by + 100), fill=PALE)
            for (x, y, r) in ((-70, -70, 70), (40, -90, 80), (110, -10, 70), (-110, 10, 70), (0, 40, 80)):
                sd.ellipse((bx + x - r, by + y - r, bx + x + r, by + y + r), fill=PALE)
            sd.ellipse((bx - 40, by + 130, bx, by + 170), fill=PALE); sd.ellipse((bx - 80, by + 190, bx - 56, by + 214), fill=PALE)
            for kx in (-60, 0, 60): sd.ellipse((bx + kx - 16, by - 16, bx + kx + 16, by + 16), fill=DARK)
            im = Image.alpha_composite(im, layer_alpha(sub, p))
        items = [('Ask calmly', chat_icon, a2, (W / 2 + 60, CY - 110), 560, 150, 58),
                 ('Take a break', break_icon, a2 + 0.6, (W / 2 + 60, CY + 80), 560, 150, 58),
                 ('Kind', None, a2 + 1.5, (W / 2 + 520, CY - 110), 260, 120, 54),
                 ('Safe', None, a2 + 1.9, (W / 2 + 520, CY + 80), 260, 120, 54)]
        for txt, ic, t0, (cx, cy), w, h, fs in items:
            p = appear(tn, t0)
            if p > 0:
                sub = Image.new('RGBA', (W, H), (0, 0, 0, 0)); sd = ImageDraw.Draw(sub)
                if ic is None:
                    card(sd, cx, cy, w, h, txt, fs, border=LIME, fill=WHITE, tcol=DARK)
                else:
                    card(sd, cx, cy, w, h, txt, fs, icon=ic)
                sub = sub.transform((W, H), Image.AFFINE, (1, 0, -80 * (1 - p), 0, 1, 0))
                im = Image.alpha_composite(im, layer_alpha(sub, p))
    elif k == 3:
        a6 = seg[6][0]; a7 = seg[7][0]
        # Ask calmly card + tick, then moves up/shrinks out when the loop appears
        p = appear(tn, seg[5][0])
        q = appear(tn, a7 - 0.35, 0.3)
        if p > 0 and q < 1:
            sub = Image.new('RGBA', (W, H), (0, 0, 0, 0)); sd = ImageDraw.Draw(sub)
            card(sd, W / 2, CY - 10, 720, 170, 'Ask calmly', 72, icon=chat_icon)
            pt = appear(tn, a6 + 0.2, 0.35)
            if pt > 0:
                cx, cy, r = W / 2 + 360, CY - 95, 56 * pt
                sd.ellipse((cx - r, cy - r, cx + r, cy + r), fill=DARK)
                if pt > 0.6: sd.line((cx - 26, cy + 2, cx - 6, cy + 22, cx + 28, cy - 18), fill=WHITE, width=13)
            im = Image.alpha_composite(im, layer_alpha(sub, p * (1 - q)))
        if q > 0:
            sub = Image.new('RGBA', (W, H), (0, 0, 0, 0)); sd = ImageDraw.Draw(sub)
            xs = [W / 2 - 430, W / 2, W / 2 + 430]
            for j, s in enumerate(['1 Stop', '2 Think', '3 Do']):
                pj = appear(tn, a7 + 0.05 + 0.15 * j)
                if pj > 0:
                    card(sd, xs[j], CY - 60 + 30 * (1 - pj), 330, 140, s, 62)
            pa = appear(tn, a7 + 0.6, 0.8)
            if pa > 0:
                # circular return arrow under the cards, drawn progressively from right to left
                box = (W / 2 - 430, CY + 10, W / 2 + 430, CY + 230)
                sd.arc(box, 0, 180 * pa, fill=MID, width=14)
                if pa >= 1:
                    ex, ey = W / 2 - 430, CY + 120
                    sd.polygon([(ex - 30, ey + 10), (ex + 30, ey + 10), (ex, ey - 40)], fill=MID)
            im = Image.alpha_composite(im, layer_alpha(sub, q))
    return im

LABELS = ['A big feeling', '1 Stop', '2 Think', '3 Do']
def gap_bounds(k):  # transition into scene k happens in the gap before it
    if k == 0: return (0, LEAD)
    return (scene_speech_end[k - 1], scene_speech_end[k - 1] + GAP)

def strip_state(tn):
    # fill fraction for each of the 3 pills; pill j (scene j+1) fills across the gap before scene j+1
    fr = []
    for j in range(3):
        g0, g1 = gap_bounds(j + 1)
        fr.append(ease((tn - g0) / (g1 - g0)))
    return fr

def base(tn, captions=None):
    im = Image.new('RGBA', (W, H), BG + (255,)); d = ImageDraw.Draw(im)
    d.rectangle((0, 800, W, H), fill=(232, 236, 220))
    # logo plate
    rr(d, (1630, 30, 1890, 220), 26, fill=WHITE)
    im.paste(logo, (1760 - logo.width // 2, 125 - logo.height // 2))
    # which scene
    k = 0
    for j in range(1, 4):
        if tn >= gap_bounds(j)[0]: k = j
    g0, g1 = gap_bounds(k)
    # outgoing content fades during first 0.4 s of the gap, incoming label slides 0.25..0.85
    if k > 0 and tn < g0 + 0.45:
        out = scene_content(k - 1, tn)
        fa = 1 - ease((tn - g0) / 0.45)
        im = Image.alpha_composite(im, layer_alpha(out, fa))
        # old label slides out to the left
        lab = Image.new('RGBA', (W, H), (0, 0, 0, 0)); ld = ImageDraw.Draw(lab)
        draw_label(ld, LABELS[k - 1], W / 2 - 300 * (1 - fa))
        im = Image.alpha_composite(im, layer_alpha(lab, fa))
    pl = ease((tn - (g0 + 0.25 if k > 0 else 0.0)) / 0.6) if k > 0 else ease(tn / 0.35)
    lab = Image.new('RGBA', (W, H), (0, 0, 0, 0)); ld = ImageDraw.Draw(lab)
    draw_label(ld, LABELS[k], W / 2 + 300 * (1 - pl))
    im = Image.alpha_composite(im, layer_alpha(lab, pl))
    im = Image.alpha_composite(im, scene_content(k, tn))
    d = ImageDraw.Draw(im)
    # step strip in the lower band, big
    fr = strip_state(tn)
    xs = [W / 2 - 520, W / 2, W / 2 + 520]
    for j, s in enumerate(['1 Stop', '2 Think', '3 Do']):
        x0, y0, x1, y1 = xs[j] - 230, 880, xs[j] + 230, 1020
        rr(d, (x0, y0, x1, y1), 70, fill=WHITE, outline=PALE, width=6)
        f = fr[j]
        if f > 0:
            m = Image.new('L', (W, H), 0); md = ImageDraw.Draw(m); md.rounded_rectangle((x0, y0, x1, y1), 70, fill=255)
            clip = Image.new('L', (W, H), 0); ImageDraw.Draw(clip).rectangle((x0, y0, x0 + (x1 - x0) * f, y1), fill=255)
            m = Image.fromarray(np.minimum(np.array(m), np.array(clip)))
            im.paste(Image.new('RGBA', (W, H), DARK + (255,)), (0, 0), m); d = ImageDraw.Draw(im)
        col = WHITE if f >= 0.5 else (150, 160, 130)
        ctext(d, xs[j], 950, s, font('Bold', 64), col)
    if captions:
        cue = next((c for c in captions if c[0] <= tn < c[1]), None)
        if cue:
            f = font('SemiBold', 50); txt = cue[2]
            b = d.textbbox((0, 0), txt, font=f); w = b[2] - b[0]
            rr(d, (W / 2 - w / 2 - 30, 720, W / 2 + w / 2 + 30, 800), 16, fill=(30, 40, 20))
            ctext(d, W / 2, 760, txt, f, WHITE)
    return im.convert('RGB')

def draw_label(d, s, cx):
    f = font('Bold', 86); b = d.textbbox((0, 0), s, font=f); w = b[2] - b[0]
    rr(d, (cx - w / 2 - 60, 80, cx + w / 2 + 60, 210), 65, fill=DARK)
    ctext(d, cx, 145, s, f, WHITE)

# captions
EN = ['A big feeling can make it hard to choose what to do.', 'Stop. Pause and notice how you feel.',
      'Think. What could you say or do that is kind and safe?', 'Do. Try your choice.', 'You can stop and think again.']
AR = ['قد يجعل الشعور القوي اختيار ما نفعله أمراً صعباً.', 'توقّف. تمهّل ولاحظ شعورك.',
      'فكّر. ماذا يمكنك أن تقول أو تفعل بطريقة لطيفة وآمنة؟', 'افعل. جرّب اختيارك.', 'يمكنك أن تتوقّف وتفكّر من جديد.']
cues = [(seg[0][0], seg[0][1] + 0.6), (seg[1][0], seg[2][1] + 0.6), (seg[3][0], seg[4][1] + 0.6),
        (seg[5][0], seg[6][1] + 0.2), (seg[7][0], TOTAL)]
cues = [(round(a, 2), round(b, 2)) for a, b in cues]
json.dump({'seg': seg, 'cues': cues, 'total': TOTAL, 'scene_speech_end': scene_speech_end}, open(D + 'timing.json', 'w'), indent=1)

def ts(x, sep):
    h = int(x // 3600); m = int(x % 3600 // 60); s = x % 60
    return f'{h:02d}:{m:02d}:{int(s):02d}{sep}{int(round((s - int(s)) * 1000)):03d}'
def write_subs(texts, stem):
    with open(D + 'out/' + stem + '.vtt', 'w') as f:
        f.write('WEBVTT\n\n')
        for i, ((a, b), t) in enumerate(zip(cues, texts)): f.write(f'{i+1}\n{ts(a, ".")} --> {ts(b, ".")}\n{t}\n\n')
    with open(D + 'out/' + stem + '.srt', 'w') as f:
        for i, ((a, b), t) in enumerate(zip(cues, texts)): f.write(f'{i+1}\n{ts(a, ",")} --> {ts(b, ",")}\n{t}\n\n')
import os; os.makedirs(D + 'out', exist_ok=True)
write_subs(EN, 'SEDRA_LS02_EN_v4'); write_subs(AR, 'SEDRA_LS02_AR-captions_v4')
capcues = [(a, b, t) for (a, b), t in zip(cues, EN)]

mode = sys.argv[1] if len(sys.argv) > 1 else 'clean'
if mode == 'stills':
    for x in [float(v) for v in sys.argv[2:]]:
        base(x, capcues).save(D + f'still_{x:.1f}.png')
    print(TOTAL); sys.exit()
out = D + f'out/SEDRA_LS02_EN_v4_{mode}.mp4'
p = subprocess.Popen(['ffmpeg', '-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS), '-i', '-',
                      '-i', D + 'narration_v4.wav', '-c:v', 'libx264', '-preset', 'medium', '-crf', '23', '-pix_fmt', 'yuv420p',
                      '-c:a', 'aac', '-b:a', '128k', '-ar', '48000', '-shortest', '-movflags', '+faststart', out], stdin=subprocess.PIPE)
for i in range(N):
    p.stdin.write(base(i / FPS, capcues if mode == 'captioned' else None).tobytes())
p.stdin.close(); p.wait(); print(out, TOTAL)
