import soundfile as sf, numpy as np
from kokoro_onnx import Kokoro
k=Kokoro("kokoro-v1.0.onnx","voices-v1.0.bin")
lines={"s1":"A big feeling can make it hard to choose what to do.",
"s2a":"Stop.","s2b":"Pause and notice how you feel.",
"s3a":"Think.","s3b":"What could you say or do that is kind and safe?",
"s4a":"Do.","s4b":"Try your choice.","s4c":"You can stop and think again."}
for key,t in lines.items():
    a,sr=k.create(t,voice="af_heart",speed=0.8,lang="en-us")
    # trim silence
    th=0.01; idx=np.where(np.abs(a)>th)[0]; a=a[max(0,idx[0]-240):idx[-1]+2400]
    sf.write(f"{key}.wav",a,sr); print(key,sr,round(len(a)/sr,2))
