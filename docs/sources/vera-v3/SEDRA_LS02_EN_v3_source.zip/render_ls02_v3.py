# SEDRA LS02 Stop Think Do - v3 (16:9 motion graphics). Render script.
import math, json, sys, os
import numpy as np, soundfile as sf
from PIL import Image, ImageDraw, ImageFont

W, H, FPS, DUR = 1920, 1080, 30, 30.0
S = 2  # supersample for sprites
BG = (246, 247, 239); BAND = (232, 234, 217)
DARK = (74, 100, 46); MID = (109, 145, 60); LIGHT = (237, 241, 224); WHITE = (255, 255, 255)
INK = (40, 52, 30); MUTED = (150, 166, 128); TERRA = (178, 84, 60); TEAL = (70, 120, 120)
FB = "/usr/share/fonts/opentype/inter/Inter-Bold.otf"
FS = "/usr/share/fonts/opentype/inter/Inter-SemiBold.otf"
OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
os.makedirs(OUT, exist_ok=True)

def font(p, size): return ImageFont.truetype(p, size * S)

def canvas(w, h):
    im = Image.new("RGBA", (w * S, h * S), (0, 0, 0, 0)); return im, ImageDraw.Draw(im)

def done(im):
    return im.resize((im.width // S, im.height // S), Image.LANCZOS)

def ctext(d, cx, cy, txt, f, fill):
    b = d.textbbox((0, 0), txt, font=f); d.text((cx - (b[2]+b[0]) / 2, cy - (b[3]+b[1]) / 2), txt, font=f, fill=fill)

# ---------- icons (drawn in sprite coords, already *S) ----------
def heart(d, cx, cy, r, fill):
    d.ellipse([cx - r*1.0, cy - r*0.75, cx, cy + r*0.25], fill=fill)
    d.ellipse([cx, cy - r*0.75, cx + r*1.0, cy + r*0.25], fill=fill)
    d.polygon([(cx - r*0.97, cy - r*0.12), (cx + r*0.97, cy - r*0.12), (cx, cy + r*1.0)], fill=fill)

def octagon(d, cx, cy, r, fill):
    pts = [(cx + r*math.cos(math.radians(22.5 + 45*i)), cy + r*math.sin(math.radians(22.5 + 45*i))) for i in range(8)]
    d.polygon(pts, fill=fill)

def arrow(d, x1, y1, x2, y2, w, fill):
    d.line([x1, y1, x2, y2], fill=fill, width=w)
    a = math.atan2(y2 - y1, x2 - x1); L = w * 2.6
    p1 = (x2 + L*math.cos(a), y2 + L*math.sin(a))
    p2 = (x2 + L*0.9*math.cos(a + 2.4), y2 + L*0.9*math.sin(a + 2.4))
    p3 = (x2 + L*0.9*math.cos(a - 2.4), y2 + L*0.9*math.sin(a - 2.4))
    d.polygon([p1, p2, p3], fill=fill)

def tick(d, cx, cy, r, bg, fg):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=bg)
    d.line([(cx - r*0.45, cy + r*0.02), (cx - r*0.1, cy + r*0.38), (cx + r*0.5, cy - r*0.35)], fill=fg, width=int(r*0.22), joint="curve")

def speech(d, x, y, w, h, fill, dots=WHITE):
    d.rounded_rectangle([x, y, x + w, y + h], radius=h*0.22, fill=fill)
    d.polygon([(x + w*0.18, y + h), (x + w*0.42, y + h), (x + w*0.12, y + h*1.35)], fill=fill)
    for i in range(3):
        cx = x + w*(0.3 + 0.2*i); r = h*0.09; d.ellipse([cx - r, y + h/2 - r, cx + r, y + h/2 + r], fill=dots)

def cup(d, x, y, w, h, fill):
    d.rounded_rectangle([x, y + h*0.3, x + w*0.72, y + h], radius=w*0.12, fill=fill)
    lw = int(w*0.09); d.ellipse([x + w*0.55, y + h*0.45, x + w*0.98, y + h*0.82], outline=fill, width=lw)
    for i in range(2):
        sx = x + w*(0.2 + 0.25*i); d.arc([sx - w*0.08, y, sx + w*0.08, y + h*0.25], 90, 270, fill=fill, width=int(w*0.05))

def shield(d, cx, cy, r, fill):
    d.polygon([(cx - r*0.8, cy - r*0.8), (cx + r*0.8, cy - r*0.8), (cx + r*0.8, cy), (cx, cy + r), (cx - r*0.8, cy)], fill=fill)
    d.ellipse([cx - r*0.8, cy - r*0.6, cx + r*0.8, cy + r*0.6], fill=fill)

# ---------- sprite builders (return RGBA at final scale) ----------
def pill(txt, bg=DARK, fg=WHITE, size=78, padx=70, h=130):
    f = font(FB, size); tmp = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    tw = tmp.textbbox((0, 0), txt, font=f)[2] // S
    w = tw + 2*padx; im, d = canvas(w, h)
    d.rounded_rectangle([0, 0, w*S - 1, h*S - 1], radius=h*S//2, fill=bg)
    ctext(d, w*S/2, h*S/2, txt, f, fg); return done(im)

def card(txt, icon=None, w=640, h=170, bg=WHITE, border=MID, fg=DARK, size=62, selected=False):
    im, d = canvas(w + 40, h + 40)
    o = 20*S
    d.rounded_rectangle([o + 6*S, o + 10*S, o + w*S, o + h*S + 6*S], radius=34*S, fill=(0, 0, 0, 22))
    d.rounded_rectangle([o, o, o + w*S - 6*S, o + h*S - 6*S], radius=34*S, fill=(LIGHT if selected else bg), outline=border, width=(9 if selected else 6)*S)
    tx = o + w*S*0.5
    if icon:
        icon(d, o + 50*S, o + (h*S)/2); tx = o + (w*S + 130*S)/2
    f = font(FB, size); ctext(d, tx, o + h*S/2 - 3*S, txt, f, fg)
    return done(im)

def ic_speech(d, x, cy): speech(d, x, cy - 42*S, 110*S, 70*S, MID)
def ic_cup(d, x, cy): cup(d, x + 6*S, cy - 50*S, 100*S, 100*S, MID)
def ic_pause(d, x, cy):
    r = 50*S; cx = x + 55*S; d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=MID)
    d.rounded_rectangle([cx - 22*S, cy - 26*S, cx - 8*S, cy + 26*S], radius=4*S, fill=WHITE)
    d.rounded_rectangle([cx + 8*S, cy - 26*S, cx + 22*S, cy + 26*S], radius=4*S, fill=WHITE)
def ic_heart(d, x, cy): heart(d, x + 55*S, cy - 8*S, 48*S, TERRA)
def ic_kind(d, x, cy): heart(d, x + 45*S, cy - 6*S, 36*S, TERRA)
def ic_safe(d, x, cy): shield(d, x + 45*S, cy, 40*S, TEAL)
def ic_loop(d, x, cy):
    r = 44*S; cx = x + 55*S; d.arc([cx - r, cy - r, cx + r, cy + r], 40, 330, fill=MID, width=12*S)
    a = math.radians(330); ex, ey = cx + r*math.cos(a), cy + r*math.sin(a)
    d.polygon([(ex + 22*S, ey - 4*S), (ex - 12*S, ey - 18*S), (ex - 2*S, ey + 22*S)], fill=MID)

def big_icon(kind, size=300):
    im, d = canvas(size, size); c = size*S/2; r = size*S*0.42
    if kind == "feeling":
        d.ellipse([c - r, c - r, c + r, c + r], fill=LIGHT)
        heart(d, c, c - 10*S, r*0.55, TERRA)
        for i, k in enumerate([0.78, 0.92]):
            d.arc([c - r*k, c - r*k, c + r*k, c + r*k], 200, 340, fill=MID, width=8*S)
    elif kind == "stop":
        octagon(d, c, c, r, TERRA); octagon(d, c, c, r*0.86, WHITE); octagon(d, c, c, r*0.8, TERRA)
        ctext(d, c, c, "STOP", font(FB, int(size*0.2)), WHITE)
    elif kind == "think":
        d.ellipse([c - r, c - r*0.75, c + r, c + r*0.55], fill=LIGHT, outline=MID, width=8*S)
        for (dx, dy, rr) in [(-r*0.55, r*0.75, r*0.13), (-r*0.8, r*0.98, r*0.08)]:
            d.ellipse([c + dx - rr, c + dy - rr, c + dx + rr, c + dy + rr], fill=LIGHT, outline=MID, width=6*S)
        for i in range(3):
            cx = c + (i - 1)*r*0.4; rr = r*0.1; d.ellipse([cx - rr, c - r*0.1 - rr, cx + rr, c - r*0.1 + rr], fill=MID)
    elif kind == "question":
        d.ellipse([c - r*0.6, c - r*0.6, c + r*0.6, c + r*0.6], fill=WHITE, outline=MID, width=8*S)
        ctext(d, c, c, "?", font(FB, int(size*0.4)), DARK)
    elif kind == "loop":
        rr = r*0.8; d.arc([c - rr, c - rr, c + rr, c + rr], 30, 320, fill=MID, width=16*S)
        a = math.radians(320); ex, ey = c + rr*math.cos(a), c + rr*math.sin(a)
        d.polygon([(ex + 34*S, ey - 2*S), (ex - 16*S, ey - 30*S), (ex - 6*S, ey + 34*S)], fill=MID)
    return done(im)

def arrows_sprite():
    w, h = 420, 420; im, d = canvas(w, h)
    sx, sy = 30*S, h*S/2
    for ang in (-38, 0, 38):
        a = math.radians(ang); L = (300 if ang == 0 else 270)*S
        arrow(d, sx, sy, sx + L*math.cos(a), sy + L*math.sin(a), 14*S, MUTED)
    return done(im)

def tracker(active, done_upto):
    # small orientation strip: 1 Stop  2 Think  3 Do
    labels = ["1 Stop", "2 Think", "3 Do"]; w, h = 760, 90
    im, d = canvas(w, h); f = font(FS, 34); x = 0
    for i, lab in enumerate(labels):
        bw = 220*S; filled = i < done_upto or i == active
        d.rounded_rectangle([x, 8*S, x + bw, (h - 8)*S], radius=37*S,
                            fill=(DARK if filled else WHITE), outline=(DARK if filled else MUTED), width=4*S)
        ctext(d, x + bw/2, h*S/2, lab, f, (WHITE if filled else MUTED)); x += bw + 30*S
    return done(im)

def caption_sprite(txt, size=54):
    f = font(FS, size); tmp = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
    tw = tmp.textbbox((0, 0), txt, font=f)[2] // S
    w, h = tw + 80, 96; im, d = canvas(w, h)
    d.rounded_rectangle([0, 0, w*S - 1, h*S - 1], radius=22*S, fill=(30, 40, 24, 230))
    ctext(d, w*S/2, h*S/2, txt, f, WHITE); return done(im)

# ---------- timeline ----------
SR = 24000
clips = {k: sf.read(f"{k}.wav")[0] for k in ["s1", "s2a", "s2b", "s3a", "s3b", "s4a", "s4b", "s4c"]}
dur = {k: len(v)/SR for k, v in clips.items()}
start = {"s1": 0.6, "s2a": 8.0, "s3a": 15.5, "s4a": 23.0}
start["s2b"] = start["s2a"] + dur["s2a"] + 0.35
start["s3b"] = start["s3a"] + dur["s3a"] + 0.35
start["s4b"] = start["s4a"] + dur["s4a"] + 0.35
start["s4c"] = start["s4b"] + dur["s4b"] + 0.5
end = {k: start[k] + dur[k] for k in start}

audio = np.zeros(int(DUR*SR) + 1, dtype=np.float32)
for k, v in clips.items():
    i = int(start[k]*SR); audio[i:i + len(v)] += v.astype(np.float32)
peak = np.max(np.abs(audio)); audio = audio / peak * 0.89
sf.write(f"{OUT}/narration_ls02_v3.wav", audio, SR)

SCN = [(0, 7.5), (7.5, 15), (15, 22.5), (22.5, 30.0)]
def split_time(k, a, b):
    # split one narration clip into two caption halves proportional to characters
    n = len(a) + len(b); m = start[k] + dur[k]*len(a)/n; return m
EN = []; AR = []
m1 = split_time("s1", "A big feeling can make it hard ", "to choose what to do.")
EN += [(start["s1"], m1, "A big feeling can make it hard"), (m1, end["s1"] + 0.8, "to choose what to do.")]
EN += [(start["s2a"], end["s2a"] + 0.25, "Stop. Pause"[:5]), ]
EN = EN[:2]
# caption windows per brief text, aligned to real speech
EN = [
 (start["s1"], m1, "A big feeling can make it hard"),
 (m1, min(end["s1"] + 1.2, 7.3), "to choose what to do."),
 (start["s2a"], start["s2b"] + 0.55, "Stop. Pause"),
 (start["s2b"] + 0.55, min(end["s2b"] + 1.2, 14.8), "and notice how you feel."),
 (start["s3a"], split_time("s3b", "What could you say or do ", "that is kind and safe?"), "Think. What could you say or do"),
 (split_time("s3b", "What could you say or do ", "that is kind and safe?"), min(end["s3b"] + 1.2, 22.3), "that is kind and safe?"),
 (start["s4a"], end["s4b"] + 0.2, "Do. Try your choice."),
 (start["s4c"], 30.0, "You can stop and think again."),
]
AR_TXT = ["قد يجعل الشعور القوي", "اختيار ما نفعله أمراً صعباً.", "توقّف. تمهّل", "ولاحظ شعورك.",
          "فكّر. ماذا يمكنك أن تقول أو تفعل", "بطريقة لطيفة وآمنة؟", "افعل. جرّب اختيارك.", "يمكنك أن تتوقّف وتفكّر من جديد."]
AR = [(a, b, t) for (a, b, _), t in zip(EN, AR_TXT)]

def ts(t, sep="."):
    ms = int(round(t*1000)); return "%02d:%02d:%02d%s%03d" % (ms//3600000, ms//60000 % 60, ms//1000 % 60, sep, ms % 1000)
def write_caps(rows, base):
    with open(base + ".vtt", "w", encoding="utf-8") as f:
        f.write("WEBVTT\n\n")
        for i, (a, b, t) in enumerate(rows, 1): f.write(f"{i}\n{ts(a)} --> {ts(b)}\n{t}\n\n")
    with open(base + ".srt", "w", encoding="utf-8") as f:
        for i, (a, b, t) in enumerate(rows, 1): f.write(f"{i}\n{ts(a, ',')} --> {ts(b, ',')}\n{t}\n\n")
write_caps(EN, f"{OUT}/SEDRA_LS02_EN_v3")
write_caps(AR, f"{OUT}/SEDRA_LS02_AR-captions_v3")
json.dump({"start": start, "end": end, "EN": EN}, open(f"{OUT}/timing_ls02_v3.json", "w"), indent=1, ensure_ascii=False)

# ---------- elements: (sprite, x, y, t_in, scene) ----------
CX = W // 2
els = []
def add(sp, x, y, t, scene, anchor="c"):
    if anchor == "c": x -= sp.width // 2; y -= sp.height // 2
    els.append((sp, int(x), int(y), t, scene))
# scene 1
add(pill("A big feeling", bg=DARK), CX, 250, 0.2, 0)
add(big_icon("feeling", 330), 600, 560, 0.5, 0)
arr = arrows_sprite(); add(arr, 850, 560 - arr.height // 2, start["s1"] + 1.4, 0, anchor="tl")
add(big_icon("question", 230), 1300, 560, start["s1"] + 2.2, 0)
# scene 2
add(pill("1 Stop", bg=TERRA), CX, 250, 7.6, 1)
add(big_icon("stop", 320), 520, 580, start["s2a"], 1)
add(card("Pause", ic_pause, w=560), 1150, 470, start["s2b"], 1)
add(card("Notice how you feel", ic_heart, w=760, size=54), 1250, 690, start["s2b"] + 0.9, 1)
# scene 3
add(pill("2 Think", bg=DARK), CX, 250, 15.1, 2)
add(big_icon("think", 320), 480, 590, start["s3a"], 2)
add(card("Ask calmly", ic_speech, w=640), 1150, 470, start["s3b"] + 0.4, 2)
add(card("Take a break", ic_cup, w=640), 1150, 690, start["s3b"] + 1.1, 2)
add(card("Kind", ic_kind, w=300, h=130, size=50), 1630, 470, start["s3b"] + 2.2, 2)
add(card("Safe", ic_safe, w=300, h=130, size=50), 1630, 690, start["s3b"] + 2.6, 2)
# scene 4
add(pill("3 Do", bg=DARK), CX, 250, 22.6, 3)
sel = card("Ask calmly", ic_speech, w=700, selected=True, border=DARK)
add(sel, CX, 470, start["s4a"], 3)
tk, td = canvas(110, 110); tick(td, 55*S, 55*S, 48*S, DARK, WHITE); tk = done(tk)
add(tk, CX + 330, 400, start["s4b"] + 0.15, 3)
for i, lab in enumerate(["1 Stop", "2 Think", "3 Do"]):
    add(card(lab, None, w=330, h=130, size=54), CX - 470 + i*360, 710, start["s4c"] - 0.3 + i*0.3, 3)
add(big_icon("loop", 150), CX + 650, 710, start["s4c"] + 0.7, 3)

logo = Image.open("logo_plate.png").convert("RGBA")
logo = logo.resize((int(logo.width*1.15), int(logo.height*1.15)), Image.LANCZOS)
trackers = {(a, dn): tracker(a, dn) for a in (-1, 0, 1, 2) for dn in (0, 1, 2, 3)}
caps = [(a, b, caption_sprite(t)) for a, b, t in EN]

def ease(x): x = max(0.0, min(1.0, x)); return x*x*(3 - 2*x)
def scene_alpha(s, t):
    a, b = SCN[s]
    if t < a - 0.05: return 0.0
    if s < 3 and t > b - 0.35: return ease((b - t)/0.35)
    return 1.0

base = Image.new("RGBA", (W, H), BG + (255,))
ImageDraw.Draw(base).rectangle([0, 870, W, H], fill=BAND + (255,))
base.alpha_composite(logo, (W - logo.width - 60, 36))

def tracker_state(t):
    if t < 7.5: return (-1, 0)
    if t < 15: return (0, 0)
    if t < 22.5: return (1, 1)
    if t < start["s4c"] + 0.7: return (2, 2)
    return (2, 3)

def frame(t, captions):
    im = base.copy()
    im.alpha_composite(trackers[tracker_state(t)], (70, 50))
    for sp, x, y, t0, s in els:
        if t < t0: continue
        a = ease((t - t0)/0.45) * scene_alpha(s, t)
        if a <= 0.01: continue
        dy = int((1 - ease((t - t0)/0.45))*24)
        if a < 0.999:
            spa = sp.copy(); al = spa.getchannel("A").point(lambda v: int(v*a)); spa.putalpha(al)
        else: spa = sp
        im.alpha_composite(spa, (x, y + dy))
    if captions:
        for a0, b0, cs in caps:
            if a0 <= t < b0: im.alpha_composite(cs, ((W - cs.width)//2, 935)); break
    return im.convert("RGB")

import subprocess
for variant, capflag in (("clean", False), ("captioned", True)):
    cmd = ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
           "-i", f"{OUT}/narration_ls02_v3.wav", "-c:v", "libx264", "-preset", "slow", "-crf", "24", "-tune", "animation", "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "96k", "-ar", "48000", "-t", "30", "-movflags", "+faststart", f"{OUT}/SEDRA_LS02_EN_v3_{variant}.mp4"]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for n in range(int(DUR*FPS)):
        fr = frame(n/FPS, capflag); p.stdin.write(fr.tobytes())
        if variant == "clean" and n == 26*FPS: fr.save(f"{OUT}/SEDRA_LS02_EN_v3_thumbnail.png")
    p.stdin.close(); p.wait()
print(json.dumps({k: round(v, 2) for k, v in start.items()}), json.dumps({k: round(v, 2) for k, v in end.items()}))
