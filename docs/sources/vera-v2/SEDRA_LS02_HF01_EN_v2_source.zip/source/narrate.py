import json, sys, numpy as np, soundfile as sf
from kokoro_onnx import Kokoro
k=Kokoro("models/kokoro-v1.0.onnx","models/voices-v1.0.bin")
VOICE=sys.argv[1] if len(sys.argv)>1 else "af_heart"; SPEED=float(sys.argv[2]) if len(sys.argv)>2 else 0.68
units={
 "LS02":[("A big feeling can make it hard","to choose what to do.",0.6),
         ("Stop. Pause","and notice how you feel.",0.25),
         ("Think. What could you say or do","that is kind and safe?",0.6),
         ("Do. Try your choice.","You can stop and think again.",0.55)],
 "HF01":[("Hospitality means helping people","feel welcome, safe and comfortable.",0.25),
         ("Say hello in a way","that works for you.",0.7),
         ("Ask, How can I help?","Then give the guest time to respond.",0.7),
         ("A kind welcome","can make a difference.",0.2)]}
def gen(t,sp=None):
    s,sr=k.create(t,voice=VOICE,speed=sp or SPEED,lang="en-us")
    env=np.abs(s); idx=np.where(env>0.02*env.max())[0]
    return s[max(0,idx[0]-120):idx[-1]+1200],sr
out={}; SR=24000
for u,scenes in units.items():
    track=np.zeros(int(30*SR),dtype=np.float32); caps=[]
    for i,(a,b,gap) in enumerate(scenes):
        w=len((a+" "+b).split()); sp=SPEED
        for _ in range(3):
            sa,_=gen(a,sp); sb,_=gen(b,sp)
            tot=len(sa)/SR+gap+len(sb)/SR
            target=min(6.1,w/108*60)
            if tot>=target-0.25 or sp<=0.6: break
            sp=max(0.6,sp*tot/target)
        start=i*7.5+0.45; da=len(sa)/SR; db=len(sb)/SR
        tot=da+gap+db; end=start+tot
        hold=(i+1)*7.5-end
        p=int(start*SR); track[p:p+len(sa)]=sa
        q=int((start+da+gap)*SR); track[q:q+len(sb)]=sb
        caps.append([round(start,3),round(start+da+gap*0.5,3),a]); caps.append([round(start+da+gap*0.5,3),round(min(end+0.6,(i+1)*7.5),3),b])
        w=len((a+" "+b).split())
        print(f"{u} s{i+1}: sp={sp:.2f} A={da:.2f} B={db:.2f} span={tot:.2f}s wpm={w/tot*60:.0f} hold={hold:.2f}")
        assert hold>0.6
    track=track/ max(1e-6,np.abs(track).max())*0.89
    sf.write(f"{u}_narration.wav",track,SR); out[u]=caps
json.dump(out,open("caps.json","w"),indent=1)
