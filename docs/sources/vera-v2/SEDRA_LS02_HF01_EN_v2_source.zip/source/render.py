import sys, subprocess
from playwright.sync_api import sync_playwright
unit, caps, out, step = sys.argv[1], sys.argv[2]=="1", sys.argv[3], (sys.argv[4] if len(sys.argv)>4 else None)
FPS=30
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={"width":1080,"height":1920})
    pg.goto(f"file:///home/claude/sedra/build/{unit}.html"); pg.wait_for_timeout(300)
    if step:  # stills mode: comma-separated times -> PNGs
        for t in step.split(","):
            pg.evaluate(f"setT({t},{str(caps).lower()})"); pg.screenshot(path=f"{out}_{t}.png")
    else:
        ff=subprocess.Popen(["ffmpeg","-y","-loglevel","error","-f","image2pipe","-framerate",str(FPS),"-i","-",
            "-c:v","libx264","-preset","slow","-crf","18","-pix_fmt","yuv420p","-r",str(FPS),"-vsync","cfr","-movflags","+faststart",out],stdin=subprocess.PIPE)
        for f in range(30*FPS):
            pg.evaluate(f"setT({f/FPS:.4f},{str(caps).lower()})")
            ff.stdin.write(pg.screenshot(type="png"))
        ff.stdin.close(); ff.wait()
    b.close()
