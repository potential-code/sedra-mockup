SEDRA LS02 + HF01 sample videos, v2 editable source.
- build_scenes.py: scene layout and timing (HTML/SVG, 1080x1920). Edit text, colours or timings here, then run it to regenerate build/*.html.
- render.py: renders 30 s at 30 fps with Playwright + ffmpeg (arg 2 = 1 burns in captions).
- narrate.py: Kokoro TTS narration (voice af_heart) and caption timings (caps.json).
- package.py: muxes audio, writes VTT/SRT, transcripts and thumbnails.
Models: kokoro-v1.0.onnx and voices-v1.0.bin from github.com/thewh1teagle/kokoro-onnx releases (not included).
