import json, subprocess, shutil, pathlib, zipfile
caps=json.load(open("caps.json")); O=pathlib.Path("v2")
def ts(t,sep): h=int(t//3600); m=int(t%3600//60); s=t%60; return f"{h:02d}:{m:02d}:{s:06.3f}".replace(".",sep)
meta={
 "LS02":dict(title="LS02 Stop Think Do",
   lines=["A big feeling can make it hard to choose what to do.","Stop. Pause and notice how you feel.","Think. What could you say or do that is kind and safe?","Do. Try your choice. You can stop and think again."],
   desc=["Lena stands calmly. A card beside her reads: A big feeling.","Lena pauses. A stop sign appears with the label 1 Stop.","Label 2 Think. Two cards offer: Ask calmly, or Take a break.","Label 3 Do. Lena chooses the Ask calmly card, which is ticked. Three cards then read 1 Stop, 2 Think, 3 Do. The final scene holds."],
   alt="Three labelled cards show Stop Think Do.", thumb=29.0),
 "HF01":dict(title="HF01 A warm welcome",
   lines=["Hospitality means helping people feel welcome, safe and comfortable.","Say hello in a way that works for you.","Ask, How can I help? Then give the guest time to respond.","A kind welcome can make a difference."],
   desc=["A guest enters reception. Labels read: Welcome, Safe, Comfortable.","The host offers a welcome card that reads Hello, and waits.","The host offers a card that reads How can I help? The guest indicates a direction symbol.","The host points to a simple map. Label: A kind welcome. The final scene holds."],
   alt="A host offers a welcome card to a guest at reception.", thumb=12.0)}
for u,m in meta.items():
    p=f"SEDRA_{u}_EN_v2"
    for kind,src in [("clean",f"out/{u}_clean_noaudio.mp4"),("captioned",f"out/{u}_cap_noaudio.mp4")]:
        subprocess.run(["ffmpeg","-y","-loglevel","error","-i",src,"-i",f"{u}_narration.wav","-map","0:v","-map","1:a","-c:v","copy","-c:a","aac","-b:a","192k","-ar","48000","-t","30","-movflags","+faststart",str(O/f"{p}_{kind}.mp4")],check=True)
    c=caps[u]
    (O/f"{p}.vtt").write_text("WEBVTT\n\n"+"".join(f"{i+1}\n{ts(a,'.')} --> {ts(b,'.')}\n{t}\n\n" for i,(a,b,t) in enumerate(c)),encoding="utf-8")
    (O/f"{p}.srt").write_text("".join(f"{i+1}\n{ts(a,',')} --> {ts(b,',')}\n{t}\n\n" for i,(a,b,t) in enumerate(c)),encoding="utf-8")
    (O/f"{p}_transcript.txt").write_text(f"SEDRA {m['title']} (English, v2)\nVerbatim narration transcript\n\n"+"\n".join(m["lines"])+"\n",encoding="utf-8")
    d=f"SEDRA {m['title']} (English, v2)\nDescriptive transcript\n\n"
    for i,(l,ds) in enumerate(zip(m["lines"],m["desc"])):
        d+=f"[{i*7.5:04.1f}–{(i+1)*7.5:04.1f} s] {ds}\nNarrator: {l}\n\n"
    d+=f"Thumbnail alt text: {m['alt']}\nNarration: synthetic voice (Kokoro TTS, voice af_heart). No music or sound effects.\n"
    (O/f"{p}_descriptive_transcript.txt").write_text(d,encoding="utf-8")
    subprocess.run(["ffmpeg","-y","-loglevel","error","-ss",str(m["thumb"]),"-i",str(O/f"{p}_clean.mp4"),"-frames:v","1",str(O/f"{p}_thumbnail.png")],check=True)
# editable source
with zipfile.ZipFile(O/"SEDRA_LS02_HF01_EN_v2_source.zip","w",zipfile.ZIP_DEFLATED) as z:
    for f in ["build_scenes.py","render.py","narrate.py","package.py","caps.json","LS02_narration.wav","HF01_narration.wav","assets/sedra_logo.png","build/LS02.html","build/HF01.html"]:
        z.write(f,f"source/{f}")
    z.writestr("source/README.txt","SEDRA LS02 + HF01 sample videos, v2 editable source.\n- build_scenes.py: scene layout and timing (HTML/SVG, 1080x1920). Edit text, colours or timings here, then run it to regenerate build/*.html.\n- render.py: renders 30 s at 30 fps with Playwright + ffmpeg (arg 2 = 1 burns in captions).\n- narrate.py: Kokoro TTS narration (voice af_heart) and caption timings (caps.json).\n- package.py: muxes audio, writes VTT/SRT, transcripts and thumbnails.\nModels: kokoro-v1.0.onnx and voices-v1.0.bin from github.com/thewh1teagle/kokoro-onnx releases (not included).\n")
