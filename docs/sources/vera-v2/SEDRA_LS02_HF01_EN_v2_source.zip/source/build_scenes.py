"""SEDRA sample videos v2 — scene HTML generator (1080x1920, 30 s, 4 x 7.5 s scenes).
Each element carries data-in / data-out (seconds) and optional data-fx (fade|up|left|pop).
render.py seeks time t and screenshots each frame."""
import base64, json, pathlib

LOGO = base64.b64encode(pathlib.Path("assets/sedra_logo.png").read_bytes()).decode()
DARK, MID, LIME, PALE, GOLD = "#4b662f", "#6d923d", "#98ac3c", "#becc96", "#86754c"
INK = "#26301c"; BG = "#f7f8f2"

CSS = f"""
*{{box-sizing:border-box;margin:0;padding:0}}
html,body{{width:1080px;height:1920px;overflow:hidden;background:{BG};font-family:Inter,sans-serif;color:{INK}}}
.stage{{position:absolute;inset:0}}
.scene{{position:absolute;inset:0}}
.el{{position:absolute}}
.logo{{position:absolute;top:60px;right:70px;width:200px;z-index:20;background:#fff;padding:12px 14px;border-radius:18px}}
.card{{background:#fff;border:6px solid {DARK};border-radius:34px;box-shadow:0 10px 0 rgba(75,102,47,.18);
  display:flex;align-items:center;justify-content:center;gap:22px;font-weight:700;color:{DARK};text-align:center;line-height:1.1}}
.label{{font-weight:800;color:{DARK};text-align:center;width:100%;letter-spacing:.5px}}
.pill{{border-radius:999px;background:{DARK};color:#fff;font-weight:800;display:flex;align-items:center;justify-content:center}}
.step{{background:#fff;border:5px solid {MID};border-radius:26px;font-weight:800;color:{DARK};display:flex;align-items:center;justify-content:center;font-size:46px}}
.cap{{position:absolute;z-index:30;left:110px;right:110px;bottom:270px;display:flex;justify-content:center}}
.cap span{{background:rgba(18,22,14,.92);color:#fff;font-size:60px;font-weight:600;line-height:1.25;padding:20px 34px;border-radius:18px;text-align:center;max-width:860px}}
"""

def person(skin, top, bottom, hair, hair_style="bun", w=360, scarf=None, arm="down"):
    """Flat front-facing standing figure, viewBox 0 0 360 1000."""
    hairs = {
        "bun": f'<circle cx="180" cy="60" r="42" fill="{hair}"/><path d="M108 150 Q110 70 180 68 Q250 70 252 150 Q240 112 180 108 Q120 112 108 150Z" fill="{hair}"/>',
        "short": f'<path d="M110 150 Q108 66 180 64 Q252 66 250 150 Q236 104 180 102 Q124 104 110 150Z" fill="{hair}"/>',
    }
    head = f'<circle cx="180" cy="160" r="74" fill="{skin}"/>'
    if scarf:
        head = (f'<path d="M92 175 Q90 70 180 66 Q270 70 268 175 L276 300 Q180 330 84 300Z" fill="{scarf}"/>'
                f'<ellipse cx="180" cy="168" rx="60" ry="70" fill="{skin}"/>')
        hair_svg = ""
    else:
        hair_svg = hairs[hair_style]
    eyes = '<circle cx="155" cy="165" r="7" fill="#2b2b2b"/><circle cx="205" cy="165" r="7" fill="#2b2b2b"/><path d="M160 200 Q180 210 200 200" stroke="#5a3a2a" stroke-width="5" fill="none" stroke-linecap="round"/>'
    if arm == "point":   # right arm (viewer's right) raised forward
        arms = (f'<path d="M86 300 Q60 420 72 540" stroke="{top}" stroke-width="54" stroke-linecap="round" fill="none"/>'
                f'<circle cx="72" cy="556" r="26" fill="{skin}"/>'
                f'<path d="M274 300 Q316 300 326 220" stroke="{top}" stroke-width="54" stroke-linecap="round" fill="none"/>'
                f'<circle cx="328" cy="200" r="26" fill="{skin}"/>')
    elif arm == "hold":  # both forearms forward holding something at chest
        arms = (f'<path d="M86 300 Q70 400 120 450" stroke="{top}" stroke-width="54" stroke-linecap="round" fill="none"/>'
                f'<path d="M274 300 Q290 400 240 450" stroke="{top}" stroke-width="54" stroke-linecap="round" fill="none"/>'
                f'<circle cx="130" cy="456" r="26" fill="{skin}"/><circle cx="230" cy="456" r="26" fill="{skin}"/>')
    else:
        arms = (f'<path d="M86 300 Q60 420 72 540" stroke="{top}" stroke-width="54" stroke-linecap="round" fill="none"/>'
                f'<path d="M274 300 Q300 420 288 540" stroke="{top}" stroke-width="54" stroke-linecap="round" fill="none"/>'
                f'<circle cx="72" cy="556" r="26" fill="{skin}"/><circle cx="288" cy="556" r="26" fill="{skin}"/>')
    body = (f'<rect x="160" y="222" width="40" height="40" fill="{skin}"/>'
            f'<path d="M86 300 Q90 250 180 248 Q270 250 274 300 L262 600 L98 600Z" fill="{top}"/>'
            f'<path d="M104 590 L256 590 L248 930 L196 930 L180 690 L164 930 L112 930Z" fill="{bottom}"/>'
            f'<ellipse cx="138" cy="940" rx="40" ry="18" fill="#3a3a32"/><ellipse cx="222" cy="940" rx="40" ry="18" fill="#3a3a32"/>')
    return (f'<svg viewBox="0 0 360 1000" width="{w}" height="{w*1000/360:.0f}" xmlns="http://www.w3.org/2000/svg">'
            f'{body}{arms}{hair_svg}{head}{eyes}</svg>')

def el(html, x, y, t_in=None, t_out=None, fx="fade", w=None, h=None, extra=""):
    st = f"left:{x}px;top:{y}px;" + (f"width:{w}px;" if w else "") + (f"height:{h}px;" if h else "") + extra
    a = (f' data-in="{t_in}"' if t_in is not None else "") + (f' data-out="{t_out}"' if t_out is not None else "")
    return f'<div class="el" style="{st}" data-fx="{fx}"{a}>{html}</div>'

def scene(i, body, bg=None):
    s, e = i*7.5, (i+1)*7.5
    return f'<div class="scene" data-s="{s}" data-e="{e}" style="background:{bg or BG}">{body}</div>'

ICON_CHAT = f'<svg width="74" height="64" viewBox="0 0 74 64"><path d="M8 6h58a6 6 0 0 1 6 6v30a6 6 0 0 1-6 6H30L14 60V48H8a6 6 0 0 1-6-6V12a6 6 0 0 1 6-6z" fill="{MID}"/><circle cx="22" cy="27" r="5" fill="#fff"/><circle cx="37" cy="27" r="5" fill="#fff"/><circle cx="52" cy="27" r="5" fill="#fff"/></svg>'
ICON_BREAK = f'<svg width="70" height="64" viewBox="0 0 70 64"><rect x="6" y="14" width="44" height="40" rx="8" fill="{MID}"/><path d="M50 22h6a9 9 0 0 1 0 18h-6" stroke="{MID}" stroke-width="7" fill="none"/><path d="M18 4q4 5 0 9M30 4q4 5 0 9" stroke="{PALE}" stroke-width="5" fill="none" stroke-linecap="round"/></svg>'
ICON_HEART = f'<svg width="80" height="72" viewBox="0 0 80 72"><path d="M40 68 C-14 34 6 -6 40 18 C74 -6 94 34 40 68Z" fill="{LIME}"/></svg>'
STOP = f'<svg width="230" height="230" viewBox="0 0 100 100"><polygon points="30,3 70,3 97,30 97,70 70,97 30,97 3,70 3,30" fill="#b3523b"/><polygon points="31,7 69,7 93,31 93,69 69,93 31,93 7,69 7,31" fill="none" stroke="#fff" stroke-width="3"/><text x="50" y="60" text-anchor="middle" font-family="Inter" font-weight="800" font-size="27" fill="#fff">STOP</text></svg>'
CHECK = f'<svg width="70" height="70" viewBox="0 0 70 70"><circle cx="35" cy="35" r="33" fill="{DARK}"/><path d="M20 36l10 10 20-22" stroke="#fff" stroke-width="7" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>'

def floor():
    return f'<div class="el" style="left:0;top:1380px;width:1080px;height:540px;background:#e9ecdc"></div>'

# ---------------- LS02 ----------------
LENA = dict(skin="#b07a55", top=MID, bottom="#3e4a5c", hair="#2f2219", hair_style="bun")
def ls02():
    L = lambda arm="down": person(**LENA, w=330, arm=arm)
    s1 = floor() + el(L(), 150, 470) + \
         el(f'<div class="card" style="width:430px;height:250px;font-size:64px;flex-direction:column">{ICON_HEART}<span>A big feeling</span></div>', 540, 620, 0.9, None, "pop")
    s2 = floor() + el(L(), 150, 470) + \
         el(f'<div style="display:flex;flex-direction:column;align-items:center;gap:26px">{STOP}<div class="pill" style="width:300px;height:110px;font-size:62px">1 Stop</div></div>', 590, 600, 8.3, None, "pop")
    s3 = floor() + el(L(), 110, 470) + \
         el('<div class="pill" style="width:300px;height:110px;font-size:62px">2 Think</div>', 610, 430, 15.6, None, "pop") + \
         el(f'<div class="card" style="width:430px;height:190px;font-size:54px">{ICON_CHAT}<span>Ask calmly</span></div>', 545, 640, 16.4, None, "up") + \
         el(f'<div class="card" style="width:430px;height:190px;font-size:54px">{ICON_BREAK}<span>Take a break</span></div>', 545, 880, 17.0, None, "up")
    s4 = floor() + el(L("point"), 110, 470) + \
         el('<div class="pill" style="width:300px;height:110px;font-size:62px">3 Do</div>', 610, 430, None) + \
         el(f'<div class="card" style="width:430px;height:190px;font-size:54px;background:#eef3e2">{ICON_CHAT}<span>Ask calmly</span></div>', 545, 640) + \
         el(CHECK, 935, 610, 23.3, None, "pop") + \
         el(f'<div class="card" style="width:430px;height:190px;font-size:54px">{ICON_BREAK}<span>Take a break</span></div>', 545, 880, None, 23.6, "fade") + \
         "".join(el(f'<div class="step" style="width:240px;height:116px">{t}</div>', 110+i*265, 250, 24.4+i*0.7, None, "up") for i, t in enumerate(["1 Stop", "2 Think", "3 Do"]))
    return [scene(0, s1), scene(1, s2), scene(2, s3), scene(3, s4)]

# ---------------- HF01 ----------------
GUEST = dict(skin="#c99572", top=GOLD, bottom="#4a4a52", hair="#222", scarf="#5d6b4a")
HOST = dict(skin="#6b4630", top=DARK, bottom="#33402a", hair="#1d1712", hair_style="short")
def reception(sign=True):
    return (floor() +
            f'<div class="el" style="left:470px;top:400px;width:520px;height:560px;background:#e3e8d3;border-radius:24px"></div>' +
            (f'<div class="el" style="left:560px;top:430px;width:340px;height:80px;border-radius:16px;background:{DARK};color:#fff;font-size:44px;font-weight:700;display:flex;align-items:center;justify-content:center">Reception</div>' if sign else ""))
def desk():
    return (f'<div class="el" style="left:450px;top:1000px;width:560px;height:400px;background:#c8b48c;border-radius:20px 20px 0 0"></div>'
            f'<div class="el" style="left:430px;top:980px;width:600px;height:44px;background:#a8936a;border-radius:14px"></div>')
def host(arm="down"):
    return el(person(**HOST, w=300, arm=arm), 580, 560)
def guest(x=110, t_in=None, fx="fade"):
    return el(person(**GUEST, w=320), x, 520, t_in, None, fx)
def hf01():
    words = (f'<div style="display:flex;gap:18px;justify-content:center;width:860px">' +
             "".join(f'<div class="pill" style="height:96px;padding:0 30px;font-size:46px;background:{c}">{t}</div>' for t, c in [("Welcome", DARK), ("Safe", MID), ("Comfortable", "#7a8f3a")]) + '</div>')
    s1 = reception() + host() + desk() + guest(110, 0.3, "left") + el(words, 110, 250, 1.6, None, "up")
    hello = f'<div class="card" style="width:250px;height:150px;font-size:64px;border-radius:28px">Hello</div>'
    s2 = reception() + host("hold") + desk() + guest() + el(hello, 605, 770, 8.4, None, "pop") + \
         el(f'<div class="pill" style="width:260px;height:104px;font-size:56px">Hello</div>', 140, 250, 9.0, None, "up")
    q = f'<div class="card" style="width:420px;height:170px;font-size:52px">How can I help?</div>'
    arrow = f'<div class="card" style="width:150px;height:150px;border-color:{GOLD}"><svg width="90" height="70" viewBox="0 0 90 70"><path d="M6 35h62M48 12l24 23-24 23" stroke="{GOLD}" stroke-width="12" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></div>'
    s3 = reception() + host("hold") + desk() + guest() + el(q, 520, 760, 15.8, None, "pop") + el(arrow, 300, 520, 18.9, None, "pop")
    mapsvg = (f'<svg width="400" height="300" viewBox="0 0 400 300"><rect width="400" height="300" rx="22" fill="#fff" stroke="{DARK}" stroke-width="6"/>'
              f'<path d="M40 240 H200 V90 H360" stroke="{PALE}" stroke-width="26" fill="none" stroke-linecap="round" stroke-linejoin="round"/>'
              f'<circle cx="40" cy="240" r="20" fill="{GOLD}"/><path d="M360 60 c-22 0-34 16-34 32 0 24 34 52 34 52s34-28 34-52c0-16-12-32-34-32z" fill="{DARK}"/><circle cx="360" cy="92" r="11" fill="#fff"/></svg>')
    s4 = reception(sign=False) + el(mapsvg, 520, 360, None) + host("point") + desk() + guest() + \
         el(f'<div class="pill" style="width:520px;height:110px;font-size:58px">A kind welcome</div>', 110, 250, 23.6, None, "up")
    return [scene(0, s1), scene(1, s2), scene(2, s3), scene(3, s4)]

def page(scenes, caps):
    capdivs = "".join(f'<div class="cap" data-in="{a}" data-out="{b}" data-fx="cut"><span>{t}</span></div>' for a, b, t in caps)
    return f"""<!doctype html><html><head><meta charset="utf-8"><style>{CSS}</style></head><body>
<div class="stage">{''.join(scenes)}</div><img class="logo" src="data:image/png;base64,{LOGO}">
<div id="caps" style="display:none">{capdivs}</div>
<script>
const ease=x=>x<0?0:x>1?1:(1-Math.cos(Math.PI*x))/2;
window.setT=function(t,showCaps){{
  document.getElementById('caps').style.display=showCaps?'block':'none';
  document.querySelectorAll('.scene').forEach(s=>{{const a=+s.dataset.s,b=+s.dataset.e;const X=0.35;
    let o = (t>=a&&t<b)?1:0; if(a>0&&t>=a-X&&t<a) o=0; if(a>0&&t>=a&&t<a+X) o=ease((t-a)/X);
    s.style.opacity=o; s.style.zIndex=(t>=a&&t<b)?2:1; s.style.display=(t>=a-0.01&&t<b+0.4)?'block':'none';}});
  document.querySelectorAll('[data-fx]').forEach(e=>{{
    const fx=e.dataset.fx, i=e.dataset.in!==undefined?+e.dataset.in:null, o=e.dataset.out!==undefined?+e.dataset.out:null;
    if(fx==='cut'){{ e.style.display=(t>=i&&t<o)?'flex':'none'; return; }}
    const D = fx==='left'?1.6:0.6;
    let p = i===null?1:ease((t-i)/D); if(o!==null) p=Math.min(p,1-ease((t-o)/0.5));
    let tr='';
    if(fx==='up') tr=`translateY(${{(1-p)*40}}px)`;
    if(fx==='left') tr=`translateX(${{(1-p)*-260}}px)`;
    if(fx==='pop') tr=`scale(${{0.92+0.08*p}})`;
    e.style.opacity = fx==='left'? Math.min(1,p*1.6) : (o!==null && i===null ? Math.max(0.35,p) : p);
    e.style.transform=tr; }});
}};
setT(0,false);
</script></body></html>"""

if __name__ == "__main__":
    caps = json.load(open("caps.json"))
    pathlib.Path("build").mkdir(exist_ok=True)
    pathlib.Path("build/LS02.html").write_text(page(ls02(), caps["LS02"]))
    pathlib.Path("build/HF01.html").write_text(page(hf01(), caps["HF01"]))
    print("ok")
