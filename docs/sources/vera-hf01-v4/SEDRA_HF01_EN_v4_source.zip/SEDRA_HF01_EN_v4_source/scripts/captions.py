"""Build EN + AR caption files (identical timings) and transcripts for HF01 v4.
Usage: python3 -I captions.py <workdir>"""
import sys, os, json
WD = sys.argv[1]; OUT = os.path.join(WD, "out")
TL = json.load(open(os.path.join(WD, "audio", "timeline.json"))); T = TL["T"]
meta = json.load(open(os.path.join(WD, "audio", "lines.json")))
# (line key, EN split chunks, AR chunks) -- AR is the suggested Arabic narration from the brief
CUES = [
    ("s1", ["Hospitality means helping people", "feel welcome, safe and comfortable."],
           ["الضيافة هي مساعدة الناس", "على الشعور بالترحيب والأمان والراحة."]),
    ("s2", ["Say hello in a way", "that works for you."],
           ["ألقِ التحية", "بالطريقة التي تناسبك."]),
    ("s3a", ["Ask, How can I help?"], ["اسأل: كيف يمكنني مساعدتك؟"]),
    ("s3b", ["Then give the guest time to respond."], ["ثم امنح الضيف وقتاً للرد."]),
    ("s4", ["A kind welcome", "can make a difference."],
           ["قد تصنع التحية", "اللطيفة فرقاً."]),
]
cues = []
for key, en, ar in CUES:
    a, b = T[key]; text = meta[key]["text"]; n = len(text)
    starts = [a]; pos = 0
    for chunk in en[:-1]:
        pos += len(chunk) + 1; starts.append(a + (b - a) * pos / n)
    ends = starts[1:] + [b]
    for i in range(len(en)):
        cues.append((starts[i], ends[i] + (0.25 if i == len(en) - 1 else 0), en[i], ar[i]))
# keep a cue on screen slightly after speech but never overlapping the next
for i in range(len(cues) - 1):
    s, e, x, y = cues[i]
    cues[i] = (s, min(e, cues[i + 1][0] - 0.04), x, y)

def ts(t, sep):
    ms = int(round(t * 1000)); h = ms // 3600000; m = ms // 60000 % 60; s = ms // 1000 % 60
    return f"{h:02d}:{m:02d}:{s:02d}{sep}{ms % 1000:03d}"
def write(lang, idx):
    base = "SEDRA_HF01_EN_v4" if lang == "en" else "SEDRA_HF01_AR-captions_v4"
    with open(os.path.join(OUT, base + ".vtt"), "w", encoding="utf-8") as f:
        f.write("WEBVTT\n\n")
        for i, c in enumerate(cues, 1):
            f.write(f"{i}\n{ts(c[0], '.')} --> {ts(c[1], '.')}\n{c[idx]}\n\n")
    with open(os.path.join(OUT, base + ".srt"), "w", encoding="utf-8") as f:
        for i, c in enumerate(cues, 1):
            f.write(f"{i}\n{ts(c[0], ',')} --> {ts(c[1], ',')}\n{c[idx]}\n\n")
write("en", 2); write("ar", 3)

# ASS for burned-in English captions (just above the step strip)
with open(os.path.join(WD, "audio", "burn.ass"), "w") as f:
    f.write("[Script Info]\nScriptType: v4.00+\nPlayResX: 1920\nPlayResY: 1080\n\n[V4+ Styles]\n"
            "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
            "Style: Cap,Inter,52,&H00FFFFFF,&H00FFFFFF,&H00202020,&HB4202020,1,0,0,0,100,100,0,0,3,14,0,2,80,80,300,1\n\n"
            "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n")
    def at(t):
        cs = int(round(t * 100)); return f"{cs // 360000}:{cs // 6000 % 60:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}"
    for c in cues:
        f.write(f"Dialogue: 0,{at(c[0])},{at(c[1])},Cap,,0,0,0,,{c[2]}\n")

full = " ".join(meta[k]["text"] for k in ["s1", "s2", "s3a", "s3b", "s4"])
open(os.path.join(OUT, "SEDRA_HF01_EN_v4_transcript.txt"), "w").write(
    "SEDRA HF01 A warm welcome (English, v4)\nTranscript (matches the audio word for word)\n\n" + full + "\n")
G1, G2, G3 = TL["GAP1"], TL["GAP2"], TL["GAP3"]; END = TL["TOTAL"]
f1 = lambda x: f"{x:04.1f}"
desc = f"""SEDRA HF01 A warm welcome (English, v4, 16:9 motion graphics, {END:.1f} s)
Descriptive transcript

[00.0-{f1(G1[0])} s] A label reads: Hospitality. A door appears, then three cards: Welcome (a door), Safe (a shield with a tick) and Comfortable (an armchair).
Narrator: {meta['s1']['text']}

[{f1(G1[0])}-{f1(G2[0])} s] The first step in the strip at the bottom fills in. A label reads: 1 Hello. A large card reads Hello. Two cards follow: a speech bubble and a hand holding a communication card.
Narrator: {meta['s2']['text']}

[{f1(G2[0])}-{f1(G3[0])} s] The second step fills in. A label reads: 2 Ask. A card reads How can I help? A clock appears and slowly fills next to a card reading Time to respond. A direction sign with an arrow appears.
Narrator: {meta['s3a']['text']} {meta['s3b']['text']}

[{f1(G3[0])}-{END:04.1f} s] The third step fills in. A label reads: 3 Welcome. A simple map appears and a path is drawn to a pin. A card with a heart reads A kind welcome and is ticked. The final scene holds for 2 seconds.
Narrator: {meta['s4']['text']}

A large step strip at the bottom (1 Hello, 2 Ask, 3 Welcome) fills in during the short pause before each step.
Thumbnail alt text: A card reads A kind welcome next to a simple map.
Narration: synthetic voice (Kokoro TTS, voice af_heart), exact English script from the brief. No music or sound effects.
"""
open(os.path.join(OUT, "SEDRA_HF01_EN_v4_descriptive_transcript.txt"), "w").write(desc)
json.dump([list(c) for c in cues], open(os.path.join(WD, "audio", "cues.json"), "w"), ensure_ascii=False, indent=1)
print(open(os.path.join(OUT, "SEDRA_HF01_EN_v4.vtt")).read())
