"""HF01 v4 narration: Kokoro TTS (af_heart, speed 1.0), one clip per line.
Usage: python3 -I voice.py <kokoro.onnx> <voices.bin> <outdir>"""
import sys, json, os
import numpy as np
import soundfile as sf
from kokoro_onnx import Kokoro

LINES = [
    ("s1", "Hospitality means helping people feel welcome, safe and comfortable."),
    ("s2", "Say hello in a way that works for you."),
    ("s3a", "Ask, How can I help?"),
    ("s3b", "Then give the guest time to respond."),
    ("s4", "A kind welcome can make a difference."),
]

def trim(x, sr, thr=0.008):
    idx = np.where(np.abs(x) > thr)[0]
    if len(idx) == 0:
        return x
    a = max(0, idx[0] - int(0.03 * sr))
    b = min(len(x), idx[-1] + int(0.12 * sr))
    return x[a:b]

model, voices, out = sys.argv[1:4]
os.makedirs(out, exist_ok=True)
k = Kokoro(model, voices)
meta = {}
for key, text in LINES:
    s, sr = k.create(text, voice="af_heart", speed=1.0, lang="en-us")
    s = trim(np.asarray(s, dtype=np.float32), sr)
    sf.write(os.path.join(out, key + ".wav"), s, sr)
    meta[key] = {"text": text, "dur": len(s) / sr, "sr": sr}
json.dump(meta, open(os.path.join(out, "lines.json"), "w"), indent=1)
print(json.dumps(meta, indent=1))
