"""SEDRA HF01 A warm welcome - v4 motion graphics renderer (1920x1080, 30 fps).
Same layout system as LS02 v4: light SEDRA background, step label pill at top,
SEDRA logo top right, large 1/2/3 step strip in the lower band that fills during
each pause, cards centred in the middle band.
Usage: python3 -I render.py <workdir>   (expects audio/lines.json and src/sedra_logo_frame.png)
Writes timeline.json, narration.wav, frames piped to ffmpeg -> out/clean_noaudio.mp4"""
import sys, os, json, math, subprocess, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H, FPS = 1920, 1080, 30
WD = sys.argv[1]
OUT = os.path.join(WD, "out"); os.makedirs(OUT, exist_ok=True)

# SEDRA palette
C_LIME = (0x98, 0xac, 0x3c); C_SAGE = (0xbe, 0xcc, 0x96); C_DARK = (0x4b, 0x66, 0x2f)
C_MID = (0x6d, 0x92, 0x3d); C_BROWN = (0x86, 0x75, 0x4c)
BG = (0xf3, 0xf5, 0xec); BAND = (0xe5, 0xe9, 0xda); CARD = (0xee, 0xf2, 0xe4); WHITE = (255, 255, 255)

FB = "/usr/share/fonts/opentype/inter/Inter-Bold.otf"
FSB = "/usr/share/fonts/opentype/inter/Inter-SemiBold.otf"
def font(sz, bold=True):
    return ImageFont.truetype(FB if bold else FSB, sz)

# ---------------- timeline from narration ----------------
meta = json.load(open(os.path.join(WD, "audio", "lines.json")))
SR = 24000
START, STEP_GAP, LINE_GAP, END_HOLD = 0.30, 1.20, 0.35, 2.0
order = [("s1", None), ("s2", STEP_GAP), ("s3a", STEP_GAP), ("s3b", LINE_GAP), ("s4", STEP_GAP)]
t = START; T = {}
for key, gap in order:
    if gap: t += gap
    T[key] = (round(t, 3), round(t + meta[key]["dur"], 3))
    t += meta[key]["dur"]
CONTENT_END = round(t + 0.15, 3)
TOTAL = round(CONTENT_END + END_HOLD, 3)
NF = int(round(TOTAL * FPS))
# step pauses (strip fills + label changes during these)
GAP1 = (T["s1"][1], T["s2"][0]); GAP2 = (T["s2"][1], T["s3a"][0]); GAP3 = (T["s3b"][1], T["s4"][0])

def word_time(key, word_prefix):
    """approximate time a phrase starts inside a line, by character share"""
    text = meta[key]["text"]; a, b = T[key]
    i = text.find(word_prefix)
    return a + (b - a) * i / len(text)

# narration track
audio = np.zeros(int((TOTAL) * SR) + SR, dtype=np.float32)
import soundfile as sf
for key, _ in order:
    x, sr = sf.read(os.path.join(WD, "audio", key + ".wav"), dtype="float32")
    s = int(T[key][0] * SR); audio[s:s + len(x)] += x
audio = audio[:int(TOTAL * SR)]
sf.write(os.path.join(WD, "audio", "narration.wav"), audio, SR)

# ---------------- easing / helpers ----------------
def clamp(x, a=0.0, b=1.0): return max(a, min(b, x))
def ease(x): x = clamp(x); return 1 - (1 - x) ** 3
def prog(t, t0, dur=0.45): return ease((t - t0) / dur)

def rr(draw, box, r, fill=None, outline=None, width=1):
    draw.rounded_rectangle(box, r, fill=fill, outline=outline, width=width)

S = 2  # supersample for element art
def canvas(w, h): return Image.new("RGBA", (w * S, h * S), (0, 0, 0, 0))
def done(im, w, h): return im.resize((w, h), Image.LANCZOS)

def text_center(d, cx, cy, txt, f, fill):
    bb = d.textbbox((0, 0), txt, font=f)
    d.text((cx - (bb[2] - bb[0]) / 2 - bb[0], cy - (bb[3] - bb[1]) / 2 - bb[1]), txt, font=f, fill=fill)

def card(w, h, label=None, icon=None, fsz=64, fill=CARD, edge=C_DARK, text=C_DARK, shadow=True):
    im = canvas(w + 16, h + 16); d = ImageDraw.Draw(im)
    if shadow:
        rr(d, (8 * S, 12 * S, (w + 8) * S, (h + 12) * S), 34 * S, fill=(0, 0, 0, 28))
        im = im.filter(ImageFilter.GaussianBlur(6 * S)); d = ImageDraw.Draw(im)
    rr(d, (4 * S, 4 * S, (w + 4) * S, (h + 4) * S), 34 * S, fill=fill + (255,), outline=edge + (255,), width=6 * S)
    if icon:
        icon(d, (w + 8) * S / 2, (4 + (h * 0.40 if label else h / 2)) * S, S)
    if label:
        cy = (4 + (h * 0.78 if icon else h / 2)) * S
        text_center(d, (w + 8) * S / 2, cy, label, font(fsz * S), text + (255,))
    return done(im, w + 16, h + 16)

def pill(w, h, label, fill=C_DARK, text=WHITE, fsz=80, frac=1.0, empty=None):
    """pill; when frac<1 the dark fill sweeps left->right over the empty style"""
    im = canvas(w, h); d = ImageDraw.Draw(im)
    if frac < 1.0:
        rr(d, (0, 0, w * S - 1, h * S - 1), h * S // 2, fill=(empty or BG) + (255,), outline=C_DARK + (255,), width=6 * S)
        if frac > 0:
            m = Image.new("L", im.size, 0); md = ImageDraw.Draw(m)
            md.rectangle((0, 0, int(w * S * frac), h * S), fill=255)
            full = canvas(w, h); fd = ImageDraw.Draw(full)
            rr(fd, (0, 0, w * S - 1, h * S - 1), h * S // 2, fill=fill + (255,))
            im.paste(full, (0, 0), Image.composite(full.split()[3], Image.new("L", im.size, 0), m))
        d = ImageDraw.Draw(im)
        # text: dark on empty part, white on filled part
        tl = canvas(w, h); td = ImageDraw.Draw(tl); text_center(td, w * S / 2, h * S / 2, label, font(fsz * S), C_DARK + (255,))
        tw = canvas(w, h); twd = ImageDraw.Draw(tw); text_center(twd, w * S / 2, h * S / 2, label, font(fsz * S), text + (255,))
        m = Image.new("L", im.size, 0); ImageDraw.Draw(m).rectangle((0, 0, int(w * S * frac), h * S), fill=255)
        im.alpha_composite(Image.composite(tw, tl, m))
    else:
        rr(d, (0, 0, w * S - 1, h * S - 1), h * S // 2, fill=fill + (255,))
        text_center(d, w * S / 2, h * S / 2, label, font(fsz * S), text + (255,))
    return done(im, w, h)

# ---------------- icons (drawn at supersample scale) ----------------
def ic_door(d, cx, cy, s):
    k = s
    d.rounded_rectangle((cx - 70 * k, cy - 100 * k, cx + 70 * k, cy + 95 * k), 10 * k, outline=C_DARK, width=10 * k)
    d.polygon([(cx - 60 * k, cy - 90 * k), (cx + 25 * k, cy - 70 * k), (cx + 25 * k, cy + 105 * k), (cx - 60 * k, cy + 85 * k)], fill=C_MID)
    d.ellipse((cx + 5 * k, cy, cx + 19 * k, cy + 14 * k), fill=WHITE)
def ic_shield(d, cx, cy, s):
    k = s
    d.polygon([(cx, cy - 95 * k), (cx + 80 * k, cy - 65 * k), (cx + 70 * k, cy + 30 * k), (cx, cy + 95 * k), (cx - 70 * k, cy + 30 * k), (cx - 80 * k, cy - 65 * k)], fill=C_MID)
    d.line([(cx - 32 * k, cy), (cx - 6 * k, cy + 28 * k), (cx + 38 * k, cy - 28 * k)], fill=WHITE, width=14 * k, joint="curve")
def ic_chair(d, cx, cy, s):
    k = s
    d.rounded_rectangle((cx - 70 * k, cy - 80 * k, cx + 70 * k, cy + 10 * k), 26 * k, fill=C_MID)
    d.rounded_rectangle((cx - 100 * k, cy - 20 * k, cx - 50 * k, cy + 60 * k), 20 * k, fill=C_DARK)
    d.rounded_rectangle((cx + 50 * k, cy - 20 * k, cx + 100 * k, cy + 60 * k), 20 * k, fill=C_DARK)
    d.rounded_rectangle((cx - 60 * k, cy + 5 * k, cx + 60 * k, cy + 55 * k), 16 * k, fill=C_LIME)
    d.rectangle((cx - 85 * k, cy + 60 * k, cx - 72 * k, cy + 95 * k), fill=C_DARK)
    d.rectangle((cx + 72 * k, cy + 60 * k, cx + 85 * k, cy + 95 * k), fill=C_DARK)
def ic_bubble(d, cx, cy, s, fill=C_MID):
    k = s
    d.rounded_rectangle((cx - 95 * k, cy - 75 * k, cx + 95 * k, cy + 45 * k), 40 * k, fill=fill)
    d.polygon([(cx - 45 * k, cy + 40 * k), (cx - 70 * k, cy + 95 * k), (cx - 5 * k, cy + 42 * k)], fill=fill)
    for dx in (-45, 0, 45):
        d.ellipse((cx + (dx - 12) * k, cy - 27 * k, cx + (dx + 12) * k, cy - 3 * k), fill=WHITE)
def ic_cardhand(d, cx, cy, s):
    k = s
    d.rounded_rectangle((cx - 90 * k, cy - 70 * k, cx + 90 * k, cy + 50 * k), 16 * k, fill=WHITE, outline=C_DARK, width=8 * k)
    d.rounded_rectangle((cx - 55 * k, cy - 30 * k, cx + 55 * k, cy - 14 * k), 8 * k, fill=C_LIME)
    d.rounded_rectangle((cx - 55 * k, cy + 2 * k, cx + 25 * k, cy + 18 * k), 8 * k, fill=C_SAGE)
    d.ellipse((cx - 30 * k, cy + 40 * k, cx + 30 * k, cy + 100 * k), fill=C_BROWN)
def ic_question(d, cx, cy, s):
    ic_bubble(d, cx, cy, s, fill=C_DARK)
def ic_arrow_sign(d, cx, cy, s):
    k = s
    d.rectangle((cx - 8 * k, cy - 20 * k, cx + 8 * k, cy + 100 * k), fill=C_BROWN)
    d.polygon([(cx - 90 * k, cy - 95 * k), (cx + 55 * k, cy - 95 * k), (cx + 100 * k, cy - 55 * k), (cx + 55 * k, cy - 15 * k), (cx - 90 * k, cy - 15 * k)], fill=C_MID)
    d.line([(cx - 55 * k, cy - 55 * k), (cx + 45 * k, cy - 55 * k)], fill=WHITE, width=12 * k)
    d.polygon([(cx + 45 * k, cy - 78 * k), (cx + 70 * k, cy - 55 * k), (cx + 45 * k, cy - 32 * k)], fill=WHITE)
def ic_heart(d, cx, cy, s):
    k = s
    d.ellipse((cx - 80 * k, cy - 70 * k, cx + 4 * k, cy + 14 * k), fill=C_MID)
    d.ellipse((cx - 4 * k, cy - 70 * k, cx + 80 * k, cy + 14 * k), fill=C_MID)
    d.polygon([(cx - 76 * k, cy - 10 * k), (cx + 76 * k, cy - 10 * k), (cx, cy + 85 * k)], fill=C_MID)

def clock_img(t_angle):
    w = h = 230
    im = canvas(w, h); d = ImageDraw.Draw(im); k = S; cx = cy = w * S / 2
    d.ellipse((15 * k, 15 * k, (w - 15) * k, (h - 15) * k), fill=WHITE, outline=C_DARK, width=10 * k)
    for i in range(12):
        a = i * math.pi / 6
        d.line([(cx + 78 * k * math.sin(a), cy - 78 * k * math.cos(a)), (cx + 90 * k * math.sin(a), cy - 90 * k * math.cos(a))], fill=C_SAGE, width=6 * k)
    a = t_angle
    d.pieslice((cx - 70 * k, cy - 70 * k, cx + 70 * k, cy + 70 * k), -90, -90 + math.degrees(a), fill=C_SAGE)
    d.line([(cx, cy), (cx + 75 * k * math.sin(a), cy - 75 * k * math.cos(a))], fill=C_DARK, width=10 * k)
    d.ellipse((cx - 12 * k, cy - 12 * k, cx + 12 * k, cy + 12 * k), fill=C_DARK)
    return done(im, w, h)

def map_img(path_frac, pin_p):
    w, h = 520, 380
    im = canvas(w, h); d = ImageDraw.Draw(im); k = S
    rr(d, (6 * k, 6 * k, (w - 6) * k, (h - 6) * k), 30 * k, fill=WHITE + (255,), outline=C_DARK + (255,), width=6 * k)
    # simple blocks (rooms)
    for bx in [(40, 40, 200, 140), (230, 40, 480, 140), (40, 240, 260, 340), (300, 240, 480, 340)]:
        rr(d, tuple(v * k for v in bx), 14 * k, fill=BAND + (255,))
    pts = [(70, 190), (250, 190), (250, 120), (420, 120)]
    # total length
    segs = [(pts[i], pts[i + 1]) for i in range(len(pts) - 1)]
    L = [math.dist(a, b) for a, b in segs]; tot = sum(L); rem = tot * clamp(path_frac)
    for (a, b), l in zip(segs, L):
        if rem <= 0: break
        f = min(1, rem / l); e = (a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f)
        d.line([(a[0] * k, a[1] * k), (e[0] * k, e[1] * k)], fill=C_MID + (255,), width=14 * k)
        d.ellipse(((e[0] - 7) * k, (e[1] - 7) * k, (e[0] + 7) * k, (e[1] + 7) * k), fill=C_MID + (255,))
        rem -= l
    d.ellipse((58 * k, 178 * k, 82 * k, 202 * k), fill=C_DARK + (255,))
    if pin_p > 0:
        px, py = 420, 120 - 40 * (1 - pin_p)
        a = int(255 * clamp(pin_p * 2))
        d.ellipse(((px - 26) * k, (py - 70) * k, (px + 26) * k, (py - 18) * k), fill=C_BROWN + (a,))
        d.polygon([((px - 22) * k, (py - 36) * k), ((px + 22) * k, (py - 36) * k), (px * k, py * k)], fill=C_BROWN + (a,))
        d.ellipse(((px - 10) * k, (py - 54) * k, (px + 10) * k, (py - 34) * k), fill=WHITE + (a,))
    return done(im, w, h)

def tick_img(p):
    w = h = 120
    im = canvas(w, h); d = ImageDraw.Draw(im); k = S
    d.ellipse((4 * k, 4 * k, (w - 4) * k, (h - 4) * k), fill=C_MID)
    pts = [(32, 62), (52, 82), (90, 40)]
    segs = [(pts[0], pts[1]), (pts[1], pts[2])]; L = [math.dist(*s_) for s_ in segs]; rem = sum(L) * clamp(p)
    for (a, b), l in zip(segs, L):
        if rem <= 0: break
        f = min(1, rem / l); e = (a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f)
        d.line([(a[0] * k, a[1] * k), (e[0] * k, e[1] * k)], fill=WHITE, width=12 * k); rem -= l
    return done(im, w, h)

# ---------------- static assets ----------------
logo_src = Image.open(os.path.join(WD, "src", "sedra_logo_frame.png")).convert("RGBA")
logo = logo_src.crop((1380, 650, 2470, 1480))
logo.thumbnail((232, 180), Image.LANCZOS)
plate = Image.new("RGBA", (256, 192), (0, 0, 0, 0)); ImageDraw.Draw(plate).rounded_rectangle((0, 0, 255, 191), 12, fill=WHITE + (255,))
plate.alpha_composite(logo, ((256 - logo.width) // 2, (192 - logo.height) // 2))

base = Image.new("RGBA", (W, H), BG + (255,))
ImageDraw.Draw(base).rectangle((0, 800, W, H), fill=BAND + (255,))
base.alpha_composite(plate, (1632, 30))

STRIP = [("1 Hello", 440), ("2 Ask", 960), ("3 Welcome", 1480)]
PW, PH = 460, 140; PY = 880
strip_cache = {}
def strip_pill(i, frac):
    key = (i, round(frac, 2))
    if key not in strip_cache:
        strip_cache[key] = pill(PW, PH, STRIP[i][0], fsz=66, frac=frac, empty=BG)
    return strip_cache[key]

LABELS = [("Hospitality", 0.0, GAP1[0]), ("1 Hello", GAP1[0], GAP2[0]), ("2 Ask", GAP2[0], GAP3[0]), ("3 Welcome", GAP3[0], 1e9)]
label_imgs = {}
for lab, _, _ in LABELS:
    f = font(80); w = int(ImageDraw.Draw(Image.new("RGB", (1, 1))).textlength(lab, font=f)) + 140
    label_imgs[lab] = pill(w, 130, lab, fsz=80)

# scene cards
C1 = [card(370, 360, "Welcome", ic_door, 56), card(370, 360, "Safe", ic_shield, 56), card(370, 360, "Comfortable", ic_chair, 50)]
DOOR = card(420, 400, None, ic_door)
HELLO = card(560, 300, "Hello", None, 110, fill=WHITE)
SAY_ICONS = [card(260, 240, None, ic_bubble), card(260, 240, None, ic_cardhand)]
QCARD = card(760, 230, "How can I help?", None, 84, fill=WHITE)
TIME_CARD = card(470, 140, "Time to respond", None, 50)
SIGN = card(280, 300, None, ic_arrow_sign)
KIND = card(560, 300, "A kind welcome", ic_heart, 60, fill=WHITE)

def place(frame, im, cx, cy, alpha=1.0, dy=0.0, scale=1.0):
    if alpha <= 0.003: return
    if scale != 1.0:
        im = im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.LANCZOS)
    if alpha < 1.0:
        im = im.copy(); a = im.split()[3].point(lambda v: int(v * alpha)); im.putalpha(a)
    frame.alpha_composite(im, (int(cx - im.width / 2), int(cy - im.height / 2 + dy)))

def appear(t, t0, t_out=None, dur=0.45, out_dur=0.35):
    """returns (alpha, dy) for a slide-up fade-in, optional fade-out"""
    p = prog(t, t0, dur); a = p; dy = 40 * (1 - p)
    if t_out is not None and t >= t_out:
        q = ease((t - t_out) / out_dur); a *= (1 - q); dy -= 30 * q
    return a, dy

CY = 470  # centre of content band

# key times
t_welcome = word_time("s1", "welcome"); t_safe = word_time("s1", "safe"); t_comf = word_time("s1", "comfortable")
t_way = word_time("s2", "in a way")
t_time = word_time("s3b", "time")
t_diff = word_time("s4", "can make")
TL = dict(T=T, GAP1=GAP1, GAP2=GAP2, GAP3=GAP3, CONTENT_END=CONTENT_END, TOTAL=TOTAL, NF=NF,
          keys=dict(welcome=t_welcome, safe=t_safe, comfortable=t_comf, way=t_way, time=t_time, difference=t_diff))
json.dump(TL, open(os.path.join(WD, "audio", "timeline.json"), "w"), indent=1)

def draw_frame(t):
    fr = base.copy()
    # ---- top step label: old slides up/out, new slides down/in during each pause ----
    for i, (lab, a0, a1) in enumerate(LABELS):
        im = label_imgs[lab]
        pin = 1.0 if i == 0 else prog(t, a0 + 0.35, 0.45)
        pout = ease((t - a1) / 0.3) if t >= a1 else 0.0
        a = pin * (1 - pout)
        if a > 0:
            dy = -50 * (1 - pin) - 50 * pout
            place(fr, im, 960, 145, a, dy)
    # ---- strip: each step fills left->right across its pause ----
    for i, gap in enumerate([GAP1, GAP2, GAP3]):
        frac = clamp((t - gap[0] - 0.1) / (gap[1] - gap[0] - 0.1))
        frac = ease(frac) if 0 < frac < 1 else frac
        place(fr, strip_pill(i, frac), STRIP[i][1], PY + PH / 2)
    # ---- scene 1: door, then Welcome / Safe / Comfortable ----
    if t < GAP1[1]:
        a, dy = appear(t, 0.05, t_welcome - 0.35)
        place(fr, DOOR, 960, CY, a, dy)
        for im, x, t0 in zip(C1, (530, 960, 1390), (t_welcome - 0.15, t_safe - 0.15, t_comf - 0.15)):
            a, dy = appear(t, t0, GAP1[0] + 0.05, out_dur=0.4)
            place(fr, im, x, CY, a, dy)
    # ---- scene 2: Hello card, then two ways to say hello ----
    if GAP1[0] < t < GAP2[1]:
        a, dy = appear(t, GAP1[0] + 0.55, GAP2[0] + 0.05)
        sh = 0.0 if t < t_way else -160 * prog(t, t_way - 0.1, 0.5)
        place(fr, HELLO, 960, CY + sh * 0 - 10, a, dy)
        for im, x, t0 in zip(SAY_ICONS, (500, 1420), (t_way - 0.05, t_way + 0.35)):
            a2, dy2 = appear(t, t0, GAP2[0] + 0.05)
            place(fr, im, x, CY, a2, dy2)
    # ---- scene 3: question card, time to respond, direction sign ----
    if GAP2[0] < t < GAP3[1]:
        a, dy = appear(t, GAP2[0] + 0.55, GAP3[0] + 0.05)
        up = -95 * prog(t, T["s3b"][0] - 0.1, 0.5)
        place(fr, QCARD, 960, CY + up, a, dy)
        a2, dy2 = appear(t, T["s3b"][0], GAP3[0] + 0.05)
        if a2 > 0:
            ang = 2 * math.pi * clamp((t - T["s3b"][0]) / 2.6)
            place(fr, clock_img(ang), 590, CY + 140, a2, dy2, 0.85)
            place(fr, TIME_CARD, 960, CY + 140, a2, dy2)
        a3, dy3 = appear(t, t_time + 0.2, GAP3[0] + 0.05)
        bob = 6 * math.sin((t - t_time) * 4) if t > t_time + 0.6 else 0
        place(fr, SIGN, 1400, CY + 60 + bob * 0.5, a3, dy3, 0.8)
    # ---- scene 4: map with path, then A kind welcome + tick; hold ----
    if t > GAP3[0]:
        a, dy = appear(t, GAP3[0] + 0.55)
        if a > 0:
            pf = clamp((t - GAP3[0] - 0.8) / 1.6); pp = prog(t, GAP3[0] + 1.9, 0.4)
            place(fr, map_img(ease(pf), pp), 640, CY, a, dy)
        a2, dy2 = appear(t, T["s4"][0] - 0.1)
        place(fr, KIND, 1290, CY - 20, a2, dy2)
        if t > t_diff:
            place(fr, tick_img(prog(t, t_diff + 0.1, 0.5)), 1290 + 270, CY - 160, prog(t, t_diff, 0.3))
    return fr

if __name__ == "__main__":
    mode = sys.argv[2] if len(sys.argv) > 2 else "video"
    if mode == "stills":
        for tt in [float(x) for x in sys.argv[3].split(",")]:
            draw_frame(tt).convert("RGB").save(os.path.join(OUT, f"still_{tt:05.2f}.png"))
        print(json.dumps(TL, indent=1)); sys.exit()
    p = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
                          "-i", os.path.join(WD, "audio", "narration.wav"), "-c:v", "libx264", "-preset", "medium", "-crf", "20", "-pix_fmt", "yuv420p",
                          "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-shortest", "-movflags", "+faststart", os.path.join(OUT, "clean.mp4")], stdin=subprocess.PIPE)
    for n in range(NF):
        p.stdin.write(draw_frame(n / FPS).convert("RGB").tobytes())
    p.stdin.close(); p.wait()
    print("frames", NF, "total", TOTAL)
