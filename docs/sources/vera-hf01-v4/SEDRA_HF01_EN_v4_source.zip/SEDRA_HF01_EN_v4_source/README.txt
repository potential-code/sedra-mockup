SEDRA HF01 v4 editable source
1. voice.py: Kokoro TTS (af_heart, speed 1.0), one clip per line (kokoro-onnx v1.0 model files, not included).
2. render.py: motion-graphics renderer (Python + Pillow + ffmpeg), timeline built from the narration: 0.3 s lead-in, 1.2 s between steps, 0.35 s between lines in a step, 2 s end hold.
3. captions.py: EN and AR VTT/SRT on identical timings, burn-in ASS, transcripts.
Run: python3 voice.py <onnx> <voices.bin> <workdir>/audio ; python3 render.py <workdir> ; python3 captions.py <workdir>
